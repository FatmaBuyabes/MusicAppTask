//
//  ViewController.swift
//  MusicAppTask
//
//  Created by Fatma Buyabes on 27/02/2024.
//

import UIKit
import SnapKit

class ViewController: UIViewController {

    let albumCoverImage = UIImageView()
    let backgroundImage = UIImageView()
    let blurEffectView = UIVisualEffectView(effect: UIBlurEffect(style: .regular))

    let songTitleLable = UILabel()
    let artistNameLable = UILabel()
    let startTimeLable = UILabel()
    let endTimeLable = UILabel()
    let progressBar = UISlider()
    let playButton = UIButton()
    let pauseButton = UIButton()
    let nextButton = UIButton()
    let previousButton = UIButton()

    
    
    override func viewDidLoad() {
        
        view.addSubview(backgroundImage)
        view.addSubview(blurEffectView)
        blurEffectView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
        backgroundImage.image = UIImage(named: "bg")
        

        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.addSubview(albumCoverImage)
        albumCoverImage.image = UIImage(named: "TheScientist")
        
        view.addSubview(songTitleLable)
        songTitleLable.text="The Scientist"
        songTitleLable.textColor = .white
        songTitleLable.font = UIFont.boldSystemFont(ofSize: 25)
        
        view.addSubview(artistNameLable)
        artistNameLable.text = "ColdPlay"
        artistNameLable.textColor = .white
        artistNameLable.font = UIFont.systemFont(ofSize: 20)
        
        
        view.addSubview(progressBar)
        progressBar.minimumTrackTintColor = .darkGray
        progressBar.maximumTrackTintColor = .lightGray
        
        view.addSubview(startTimeLable)
        startTimeLable.text = "0.00"
        startTimeLable.textColor = .white
        
        view.addSubview(endTimeLable)
        endTimeLable.text = "5:09"
        endTimeLable.textColor = .white
        
        view.addSubview(playButton)
        playButton.setImage(UIImage(systemName: "play"), for: .normal)
        playButton.tintColor = .white
        
        
        view.addSubview(pauseButton)
        pauseButton.setImage(UIImage(systemName: "pause"), for: .normal)
        pauseButton.tintColor = .white
        pauseButton.isHidden = true
        
        view.addSubview(nextButton)
        nextButton.setImage(UIImage(systemName: "forward.fill"), for: .normal)
        nextButton.tintColor = .white
        
        view.addSubview(previousButton)
        previousButton.setImage(UIImage(systemName: "backward.fill"), for: .normal)
        previousButton.tintColor = .white
        
        backgroundImage.snp.makeConstraints { make in
            make.edges.equalToSuperview()
            
        }
    
        
        albumCoverImage.snp.makeConstraints { make in
            make.centerX.equalTo(view.safeAreaLayoutGuide.snp.centerX).offset(0)
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(180)
            make.width.height.equalTo(300)
        }
        
        songTitleLable.snp.makeConstraints { make in
            make.centerX.equalTo(view.safeAreaLayoutGuide.snp.centerX).offset(0)
            make.bottom.equalTo(albumCoverImage.snp.bottom).offset(50)

        }
        artistNameLable.snp.makeConstraints { make in
            make.centerX.equalTo(view.safeAreaLayoutGuide.snp.centerX).offset(0)
            make.bottom.equalTo(songTitleLable.snp.bottom).offset(30)
            

        }
        progressBar.snp.makeConstraints { make in
            make.centerX.equalTo(view.safeAreaLayoutGuide.snp.centerX).offset(0)
            make.bottom.equalTo(artistNameLable.snp.bottom).offset(30)
            make.leading.equalToSuperview().offset(30)
            make.trailing.equalToSuperview().offset(-30)
        }
        
        startTimeLable.snp.makeConstraints { make in

            make.centerX.equalTo(progressBar.snp.leading).offset(0)
            make.bottom.equalTo(progressBar.snp.bottom).offset(20)
        }
        
        endTimeLable.snp.makeConstraints { make in
            make.centerX.equalTo(progressBar.snp.trailing).offset(0)
            make.bottom.equalTo(progressBar.snp.bottom).offset(20)
        }
        
        playButton.snp.makeConstraints { make in
            make.bottom.equalTo(progressBar.snp.bottom).offset(70)
            make.centerX.equalTo(view.safeAreaLayoutGuide.snp.centerX).offset(0)
            

        }
        
        pauseButton.snp.makeConstraints { make in
            make.bottom.equalTo(progressBar.snp.bottom).offset(70)
            make.centerX.equalTo(view.safeAreaLayoutGuide.snp.centerX).offset(0)

        }
        
        nextButton.snp.makeConstraints { make in
            make.centerY.equalTo(playButton.snp.centerY).offset(0)
            make.right.equalTo(playButton.snp.right).offset(90)

        }
        
        previousButton.snp.makeConstraints { make in
            make.centerY.equalTo(playButton.snp.centerY).offset(0)
            make.left.equalTo(playButton.snp.left).offset(-90)

            
        }
        
    }

}

